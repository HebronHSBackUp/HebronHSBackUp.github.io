public class Tower {
    public static void main(String[] args) {
        System.out.println("  #####");
        System.out.println("  |||||");
        System.out.println("  |||||");
        System.out.println("  |||||");
        System.out.println("  |||||");
        System.out.println("  #####");
        System.out.println("~~~~~~~~~");
        System.out.println("|-O-*-O-|");
        System.out.println("~~~**~~~~");
        System.out.println("|-*-*-O-|");
        System.out.println("~*~~*~~~~");
        System.out.println("|-O-*-O-|");
        System.out.println("~~~~*~~~~");
        System.out.println("|-O-*-O-|");
        System.out.println("~~~~*~~~~");
        System.out.println("|-O-*-O-|");
        System.out.println("~~~~*~~~~");
        System.out.println("|-O-*-O-|");
        System.out.println("~~~~*~~~~");
        System.out.println("|-O-*-O-|");
        System.out.println("~~~~*~~~~");
        System.out.println("|-O-*-O-|");
        System.out.println("~~~~*~~~~");
        System.out.println("|*******|");
        System.out.println("~~~~~~~~~");
    }
}
