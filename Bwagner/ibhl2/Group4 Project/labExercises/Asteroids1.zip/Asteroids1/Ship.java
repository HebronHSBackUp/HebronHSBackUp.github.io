import greenfoot.*;

public class Ship extends Actor
{
    // instance variables

    
    // constructor
    public Ship()
    {
        setImage(new GreenfootImage(30,20));   // creates a blank image to draw ship on
                                               // add sets it as the ship's image
    }
    
    public void act() 
    {
        update();
        wrapAround();
        draw();
    }
    
    // This method updates the ships position(move and turn) according to keyboard input
    // This method updates the ships position using its current velocity and acceleration
    public void update()
    {
        
    }
 
    // When the ship leaves the world(window) on one side it reappears on 
    public void wrapAround()
    {

    }
    
    // draws the ship on the image created in the constructor
    public void draw()
    {
        GreenfootImage image = getImage();
        image.setColor(Color.WHITE);
        
        image.drawLine(0, 0, 30, 10);
        image.drawLine(0, 20, 30, 10);
        image.drawLine(0, 0, 0, 20);

        setImage(image);
    }
    

    

}
