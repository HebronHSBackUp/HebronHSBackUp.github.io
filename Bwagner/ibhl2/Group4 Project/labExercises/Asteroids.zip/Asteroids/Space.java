import greenfoot.*;
import java.awt.Color;

/**
 * Write a description of class Space here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Space extends World
{

    /**
     * Constructor for objects of class Space.
     * 
     */
    public Space()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1, false); 
        GreenfootImage image = getBackground();
        image.setColor(Color.black);
        image.fillRect(0,0, getWidth(), getHeight());
        setBackground(image);
        
        Ship ship = new Ship();
        addObject(ship, getWidth()/2, getHeight()/2);
      
    }
}
