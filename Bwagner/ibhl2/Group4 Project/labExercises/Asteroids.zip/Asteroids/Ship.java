import greenfoot.*;
import java.awt.Color;

public class Ship extends Actor
{
    // instance variables
    private double vx = 0;                    // horizonal velocity
    private double vy = 0;                    // vertical velocity
    private double ax = 0;                    // horizontal acceleration
    private double ay = 0;                    // vertical acceleration
    private double angle = 0;                 // amount of rotation
    private double thrust = .1;               // amount of thrust  (starts off small but increases as you hold down up arrow key)
    private boolean thrusting = false;        // true if thrusting; false otherwise
    private boolean turnLeft = false;         // true if rotating left; false otherwise
    private boolean turnRight = false;        // true if rotating right; false otherwise
    
    // constructor
    public Ship()
    {
        setImage(new GreenfootImage(30,20));
        draw();
    }
    
    public void act() 
    {
        update();
        wrapAround();
        draw();
    }
    
    // monitors keyboard input and updates the ship's position, speed(thrusting), and direction(rotation).
    public void update()
    {

       
    }
    
    // repositions the ship so that if it goes off one side of the screen it will reappear on opposite side of screen retaining its current speed amd direction
    public void wrapAround()
    {
 
    }
    
    
    // draws ship on screen
    public void draw()
    {
        GreenfootImage image = getImage();
        image.setColor(Color.white);
        
        image.drawLine(0, 0, 30, 10);
        image.drawLine(0, 20, 30, 10);
        image.drawLine(0, 0, 0, 20);

        setImage(image);
    }
    
}
