import greenfoot.*;

/**
 * Write a description of class RandomBug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RandomBug extends Tracker
{
    public void act() 
    {
        
    }    
}
